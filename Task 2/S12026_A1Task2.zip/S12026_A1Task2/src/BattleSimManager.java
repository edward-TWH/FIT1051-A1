/**
 * The BattleSimManager class is responsible for managing the overall battle
 * simulation. It handles player creation, monster initialization, and running
 * the simulation flow including battles.
 *
 * @author FIT1051 Admin
 * @version 1.0 - created the basic scaffold for the class
 */
public class BattleSimManager
{

    private Character player;
    private Monster monster;

    /**
     * Default constructor that initializes a new player and a default Goblin
     * monster with 70 HP, 20 attack and 4 defense.
     */
    public BattleSimManager()
    {
        player = new Character();
        monster = new Monster("Goblin", 70, 20, 4);
    }

    /**
     * Constructs a BattleSimManager with a specified player. A default Goblin
     * monster with 70 HP, 20 attack and 4 defense is also initialized.
     *
     * @param player the player character
     */
    public BattleSimManager(Character player)
    {
        this.player = player;
        this.monster = new Monster("Goblin", 70, 20, 4);
    }

    /**
     * Simulates a battle between the player and the monster.
     *
     * @return the Character who wins the battle
     */
    public String battle()
    {

        return null;
    }

    /**
     * Returns the current monster.
     *
     * @return the monster opponent
     */
    public Monster getMonster()
    {
        return monster;
    }

    /**
     * Returns the player character.
     *
     * @return the player
     */
    public Character getPlayer()
    {
        return player;
    }

    /**
     * Runs the simulation by displaying a menu and processing user input.
     */
    public void runSimulation()
    {

        // todo: implement logic here

    }

    /**
     * Sets the monster opponent.
     *
     * @param monster the monster to set
     */
    public void setMonster(Monster monster)
    {
        this.monster = monster;
    }

    /**
     * Sets the player character.
     *
     * @param player the player to set
     */
    public void setPlayer(Character player)
    {
        this.player = player;
    }

    /**
     * Returns a string representation of the battle setup.
     *
     * @return a string showing the player and monster
     */
    @Override
    public String toString()
    {
        return player + " fights " + monster;
    }
}
