/**
 * The main driving class to the Labyrinth Battle Simulator.
 *
 * @author FIT1051, todo: <add your name here>
 * @version 1.0 - created a scaffold for Task 1 with a main method and to-do
 * tasks
 */
public class BattleSimulatorDriver
{

    /**
     * Main method, this is where execution starts
     *
     * @param args command line arguments
     */
    public static void main(String[] args)
    {
        // creating an object of the BattleSimulatorDriver class so that we can
        // call the runSimulation method
        BattleSimulatorDriver battleSimulatorDriverDriver = new BattleSimulatorDriver();
        // calling / invoking the runPlaylistManager method
        battleSimulatorDriverDriver.runSimulation();
    }

    /**
     * Main logic for the labyrinth battle simulator
     */
    public void runSimulation()
    {
        // todo: create and initialize local variables for name, health, attack
        //  and defence for the first character


        // todo: create and initialize local variables for name, health, attack
        //  and defence for the second character


        // todo: display info for both character in properly formatted String(s)


        // todo: FOR HD - in addition to above tasks - create two Character
        //  objects and display them using the toString() method.
        //  Leave empty if not attempted.


    }

}
