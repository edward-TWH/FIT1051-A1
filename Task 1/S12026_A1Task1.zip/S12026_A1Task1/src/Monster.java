/**
 * This class represents a monster in a Labyrinth Battle Simulator.
 * This class is built as reference for the HD level task.
 *
 * @author FIT1051 Admin
 * @version 1.0 - A basic Monster class with a name field, constructors,
 * getters, setters and toString method
 */
public class Monster
{

    private String name;

    /**
     * Default constructor that sets the name of the Monster to unknown
     */
    public Monster()
    {
        name = "unknown";
    }

    /**
     * Parameterized constructor that initializes the name of the Monster to
     * the parsed name
     *
     * @param name the name of the monster
     */
    public Monster(String name)
    {
        this.name = name;
    }

    /**
     * Accessor method for name of the monster
     *
     * @return name of the monster
     */
    public String getName()
    {
        return name;
    }

    /**
     * A basic mutator method for name of the monster, no guardian code.
     *
     * @param name new name for the monster
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * Returns a String containing the name of the playlist
     *
     * @return playlist name
     */
    public String toString()
    {
        return "Monster name: " + name;
    }

}
